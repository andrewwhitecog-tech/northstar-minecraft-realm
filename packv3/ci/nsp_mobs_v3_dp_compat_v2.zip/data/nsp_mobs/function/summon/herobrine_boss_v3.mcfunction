function nsp_mob:summon {carrier:"minecraft:zombie",model:"herobrine_boss_v3",pattern:"slam",cmd:480212,hp:200,damage:8,scale:3.0,dy:-4.24,loot:"nsp_mobs:entities/herobrine_boss_v3",brightness:12}
