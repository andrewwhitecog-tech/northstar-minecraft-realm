function nsp_mob:summon {carrier:"minecraft:spider",model:"horror_crawler",pattern:"charge",cmd:480203,hp:60,damage:6,scale:1.6,dy:0.58,loot:"nsp_mobs:entities/horror_crawler",brightness:12}
