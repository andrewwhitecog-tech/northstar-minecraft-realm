function nsp_mob:summon {carrier:"minecraft:vex",model:"azure_reef_manta_ray",pattern:"burst",cmd:480217,hp:50,damage:5,scale:1.6,dy:0.30,loot:"nsp_mobs:entities/azure_reef_manta_ray",brightness:12}
