function nsp_mob:summon {carrier:"minecraft:vex",model:"horror_floater_v2",pattern:"burst",cmd:480208,hp:50,damage:5,scale:1.6,dy:0.30,loot:"nsp_mobs:entities/horror_floater_v2",brightness:12}
