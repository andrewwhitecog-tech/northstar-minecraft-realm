function nsp_mob:summon {carrier:"minecraft:villager",model:"big_shroomie_v2",pattern:"idle",cmd:480210,hp:40,damage:0,scale:1.6,dy:-1.42,loot:"nsp_mobs:entities/big_shroomie_v2",brightness:12}
