function nsp_mob:summon {carrier:"minecraft:zombie",model:"horror_stalker",pattern:"charge",cmd:480202,hp:60,damage:6,scale:1.6,dy:-1.42,loot:"nsp_mobs:entities/horror_stalker",brightness:12}
