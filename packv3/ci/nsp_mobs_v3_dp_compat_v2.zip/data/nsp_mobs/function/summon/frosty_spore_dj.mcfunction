function nsp_mob:summon {carrier:"minecraft:villager",model:"frosty_spore_dj",pattern:"idle",cmd:480206,hp:40,damage:0,scale:1.6,dy:-1.42,loot:"nsp_mobs:entities/frosty_spore_dj",brightness:12}
