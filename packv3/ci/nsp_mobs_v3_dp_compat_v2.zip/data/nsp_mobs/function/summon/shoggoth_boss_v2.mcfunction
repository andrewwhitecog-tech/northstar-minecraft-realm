function nsp_mob:summon {carrier:"minecraft:zombie",model:"shoggoth_boss_v2",pattern:"slam",cmd:480207,hp:200,damage:8,scale:3.0,dy:-4.24,loot:"nsp_mobs:entities/shoggoth_boss_v2",brightness:12}
