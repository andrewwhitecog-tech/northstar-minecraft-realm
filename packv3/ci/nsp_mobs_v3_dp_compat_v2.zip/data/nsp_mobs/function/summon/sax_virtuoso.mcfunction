function nsp_mob:summon {carrier:"minecraft:villager",model:"sax_virtuoso",pattern:"idle",cmd:480205,hp:40,damage:0,scale:1.6,dy:-1.42,loot:"nsp_mobs:entities/sax_virtuoso",brightness:12}
