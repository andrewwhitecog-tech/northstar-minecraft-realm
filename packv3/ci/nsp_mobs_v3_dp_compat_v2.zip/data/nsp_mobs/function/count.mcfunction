execute if entity @e[tag=nsp_mob.carrier] run tellraw @s ["nsp mobs: ",{"nbt":"","entity":"@e[tag=nsp_mob.carrier]"}]
