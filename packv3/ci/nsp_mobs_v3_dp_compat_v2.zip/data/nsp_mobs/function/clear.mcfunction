kill @e[tag=nsp_mob.visual]
kill @e[tag=nsp_mob.carrier]
