# Explicit admin clear of library-owned actors only; administrative cleanup never awards farmable loot.
execute as @e[tag=nsp_mob.carrier] run data merge entity @s {DeathLootTable:"nsp_mob:entities/empty"}
kill @e[tag=nsp_mob.projectile]
kill @e[tag=nsp_mob.visual]
kill @e[tag=nsp_mob.carrier]
kill @e[type=minecraft:marker,tag=nsp_mob.charge_probe]
scoreboard players add #generation nspm_stat 1
