scoreboard players add @s nspm_away 1
scoreboard players set #owner nspm_stat 0
execute on origin if entity @s[tag=nsp_mob.carrier] unless entity @s[nbt={Health:0.0f}] run scoreboard players set #owner nspm_stat 1
execute if score #owner nspm_stat matches 0 run kill @s
execute if score @s nspm_away matches 160.. run kill @s
