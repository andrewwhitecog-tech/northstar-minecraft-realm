scoreboard players set #parent nspm_stat 0
execute on vehicle if entity @s[tag=nsp_mob.carrier] run scoreboard players set #parent nspm_stat 1
execute if score #parent nspm_stat matches 0 run function nsp_mob:visual_gone
