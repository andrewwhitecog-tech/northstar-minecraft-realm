# Synchronous, library-owned invisible marker computes a bounded horizontal impulse. Collision-capable carriers use native AABB collision; summon refuses Vex charge.
kill @e[type=minecraft:marker,tag=nsp_mob.charge_probe]
execute at @s rotated as @s rotated ~ 0 run summon minecraft:marker ^ ^ ^0.8 {Tags:["nsp_mob.charge_probe"]}
execute store result score #tip_x nspm_stat run data get entity @e[type=minecraft:marker,tag=nsp_mob.charge_probe,limit=1] Pos[0] 10
execute store result score #tip_z nspm_stat run data get entity @e[type=minecraft:marker,tag=nsp_mob.charge_probe,limit=1] Pos[2] 10
execute store result score #base_x nspm_stat run data get entity @s Pos[0] 10
execute store result score #base_z nspm_stat run data get entity @s Pos[2] 10
scoreboard players operation #tip_x nspm_stat -= #base_x nspm_stat
scoreboard players operation #tip_z nspm_stat -= #base_z nspm_stat
execute store result entity @s Motion[0] double 0.1 run scoreboard players get #tip_x nspm_stat
execute store result entity @s Motion[2] double 0.1 run scoreboard players get #tip_z nspm_stat
kill @e[type=minecraft:marker,tag=nsp_mob.charge_probe]
