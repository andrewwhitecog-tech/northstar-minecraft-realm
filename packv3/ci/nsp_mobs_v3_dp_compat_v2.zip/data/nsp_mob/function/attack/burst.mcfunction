# Three genuine homing projectiles, not a damage-only particle ray. Exact 1.21.1 NBT/target initialization inspected.
$execute if score @s nspm_action matches 25 run summon minecraft:shulker_bullet ~ ~1.4 ~ {Tags:["nsp_mob.projectile"],Owner:$(owner),Target:$(target),Steps:1}
$execute if score @s nspm_action matches 13 run summon minecraft:shulker_bullet ~ ~1.4 ~ {Tags:["nsp_mob.projectile"],Owner:$(owner),Target:$(target),Steps:1}
$execute if score @s nspm_action matches 1 run summon minecraft:shulker_bullet ~ ~1.4 ~ {Tags:["nsp_mob.projectile"],Owner:$(owner),Target:$(target),Steps:1}
execute if score @s nspm_action matches 25 if entity @a[distance=..28] run playsound minecraft:entity.evoker.cast_spell hostile @a[distance=..28] ~ ~ ~ 0.5 1.1
