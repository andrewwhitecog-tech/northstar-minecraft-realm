execute if score @s nspm_action matches 2.. run particle minecraft:ash ~ ~0.1 ~ 1.5 0.05 1.5 0 6 normal
execute unless score @s nspm_action matches 1 run return 0
$execute as @a[gamemode=survival,distance=..3] run damage @s 8 minecraft:mob_attack by @e[nbt={UUID:$(owner)},limit=1]
$execute if data storage nsp_mob:settings {training:1b} as @e[tag=nsp_mob.test_target,distance=..3] run damage @s 8 minecraft:mob_attack by @e[nbt={UUID:$(owner)},limit=1]
particle minecraft:block{block_state:{Name:"minecraft:deepslate"}} ~ ~0.1 ~ 1.8 0.1 1.8 0.15 22 normal
execute if entity @a[distance=..28] run playsound minecraft:entity.iron_golem.attack hostile @a[distance=..28] ~ ~ ~ 0.75 0.55
