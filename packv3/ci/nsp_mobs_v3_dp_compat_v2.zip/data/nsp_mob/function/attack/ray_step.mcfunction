# Retired pre-execution prototype; not called.
