# Face the current exact target; only rotation is teleported. Position movement uses native swept collision.
$execute facing entity @e[nbt={UUID:$(target)},limit=1] eyes rotated ~ 0 run tp @s ~ ~ ~ ~ 0
execute if score @s nspm_action matches 7.. run particle minecraft:crit ~ ~0.5 ~ 0.5 0.3 0.5 0.01 3 normal
execute if score @s nspm_action matches 1..6 run function nsp_mob:attack/charge_impulse
$execute if score @s nspm_action matches 1..6 at @s if entity @e[nbt={UUID:$(target)},distance=..2,limit=1] run damage @e[nbt={UUID:$(target)},distance=..2,limit=1] 6 minecraft:mob_attack by @s
$execute if score @s nspm_action matches 1..6 at @s if entity @e[nbt={UUID:$(target)},distance=..2,limit=1] run scoreboard players set @s nspm_action 0
