# Retired pre-execution prototype. Production burst uses real collision-tested shulker bullets.
