data modify storage nsp_mob:context rotation set from entity @s Rotation
execute on passengers if entity @s[tag=nsp_mob.visual] run data modify entity @s Rotation set from storage nsp_mob:context rotation
execute if score @s nspm_idle matches 0 on passengers if entity @s[tag=nsp_mob.visual] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{scale:[1.2f,1.2f,1.2f],left_rotation:[0f,0f,-0.0174524f,0.9998477f]}}
execute if score @s nspm_idle matches 8 on passengers if entity @s[tag=nsp_mob.visual] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{scale:[1.22f,1.24f,1.22f],left_rotation:[0f,0f,0.0174524f,0.9998477f]}}
