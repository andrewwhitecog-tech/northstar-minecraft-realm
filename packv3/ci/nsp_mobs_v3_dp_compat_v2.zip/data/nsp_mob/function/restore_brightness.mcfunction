execute unless score @s nspm_light matches 0..15 run scoreboard players set @s nspm_light 12
execute store result entity @s brightness.block int 1 run scoreboard players get @s nspm_light
data merge entity @s {Glowing:0b}
