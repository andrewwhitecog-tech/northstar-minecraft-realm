execute if entity @s[tag=nsp_mob.herobrine_boss_v2] run playsound nsp_mobs:mob.herobrine_boss_v3.special neutral @a[distance=..32] ~ ~ ~ 0.7 1
execute if entity @s[tag=nsp_mob.herobrine_boss_v3] run playsound nsp_mobs:mob.herobrine_boss_v3.special neutral @a[distance=..32] ~ ~ ~ 0.7 1
execute if entity @s[tag=nsp_mob.iron_mycelium_supreme] run playsound nsp_mobs:mob.iron_mycelium_supreme.special neutral @a[distance=..32] ~ ~ ~ 0.7 1
execute if entity @s[tag=nsp_mob.shoggoth_boss] run playsound nsp_mobs:mob.shoggoth_boss_v2.special neutral @a[distance=..32] ~ ~ ~ 0.7 1
execute if entity @s[tag=nsp_mob.shoggoth_boss_v2] run playsound nsp_mobs:mob.shoggoth_boss_v2.special neutral @a[distance=..32] ~ ~ ~ 0.7 1
execute if entity @s[tag=nsp_mob.subwoofer_warden_v2] run playsound nsp_mobs:mob.subwoofer_warden_v2.special neutral @a[distance=..32] ~ ~ ~ 0.7 1
