scoreboard objectives add nspm_phase dummy
scoreboard objectives add nspm_cd dummy
scoreboard objectives add nspm_action dummy
scoreboard objectives add nspm_hp dummy
scoreboard objectives add nspm_oldhp dummy
scoreboard objectives add nspm_hurt dummy
scoreboard objectives add nspm_idle dummy
scoreboard objectives add nspm_away dummy
scoreboard objectives add nspm_stat dummy
data remove storage nsp_mob:profile measured
scoreboard players add #generation nspm_stat 0
scoreboard objectives add nspm_perf dummy

scoreboard objectives add nspm_light dummy
