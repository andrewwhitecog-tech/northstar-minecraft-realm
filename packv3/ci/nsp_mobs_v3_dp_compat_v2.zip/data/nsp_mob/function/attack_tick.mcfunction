execute if entity @s[tag=nsp_mob.pattern.idle] run scoreboard players set @s nspm_action 0
execute if entity @s[tag=nsp_mob.pattern.idle] run return 0
execute if entity @s[type=minecraft:vex,tag=nsp_mob.pattern.charge] run scoreboard players set @s nspm_action 0
execute if entity @s[type=minecraft:vex,tag=nsp_mob.pattern.charge] run return fail
function nsp_mob:select_target
execute unless data storage nsp_mob:context target run scoreboard players set @s nspm_action 0
execute unless data storage nsp_mob:context target run return 0
execute if entity @s[tag=nsp_mob.pattern.charge] run function nsp_mob:attack/charge with storage nsp_mob:context
execute if entity @s[tag=nsp_mob.pattern.burst] run function nsp_mob:attack/burst with storage nsp_mob:context
execute if entity @s[tag=nsp_mob.pattern.slam] run function nsp_mob:attack/slam with storage nsp_mob:context
execute if score @s nspm_action matches 1.. run scoreboard players remove @s nspm_action 1
