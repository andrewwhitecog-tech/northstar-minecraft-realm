scoreboard players set @s nspm_hurt 4
scoreboard players set @s nspm_action 0
execute on passengers if entity @s[tag=nsp_mob.visual] run data merge entity @s {Glowing:1b,glow_color_override:16733525,brightness:{block:15,sky:15}}
execute if entity @a[distance=..28] run function nsp_mob:hurt_sound
particle minecraft:damage_indicator ~ ~1 ~ 0.35 0.5 0.35 0.05 6 normal
