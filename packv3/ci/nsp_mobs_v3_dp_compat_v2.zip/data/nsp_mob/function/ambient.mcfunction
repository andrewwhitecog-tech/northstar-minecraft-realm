execute if entity @s[tag=nsp_mob.azure_reef_manta_ray] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.azure_reef_manta_ray_glow] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.azure_reef_manta_ray_iridescent] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.big_shroomie_v2] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.coconut_carapace_crab] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.coconut_carapace_crab_glow] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.coconut_carapace_crab_iridescent] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.crowned_giraffe_strider_v2] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.crowned_giraffe_strider_v2_glow] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.crowned_giraffe_strider_v2_iridescent] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.frosty_spore_dj] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.goliath_tusk_elephant] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.goliath_tusk_elephant_glow] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.goliath_tusk_elephant_iridescent] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.herobrine_boss_v2] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.herobrine_boss_v3] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.horror_crawler] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.horror_floater_v2] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.horror_stalker] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.iron_mycelium_supreme] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.paradise_sunburst_toucan] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.paradise_sunburst_toucan_glow] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.paradise_sunburst_toucan_iridescent] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.savanna_lion_monarch] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.savanna_lion_monarch_glow] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.savanna_lion_monarch_iridescent] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.sax_virtuoso] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.shoggoth_boss] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.shoggoth_boss_v2] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.subwoofer_warden_v2] run return run function nsp_mob:sound/ambient
execute if entity @s[tag=nsp_mob.sound.stone] run playsound minecraft:block.deepslate.break hostile @a[distance=..28] ~ ~ ~ 0.25 0.55
execute if entity @s[tag=nsp_mob.sound.eldritch] run playsound minecraft:entity.warden.heartbeat hostile @a[distance=..28] ~ ~ ~ 0.3 0.65
execute if entity @s[tag=nsp_mob.sound.insect] run playsound minecraft:entity.bee.loop hostile @a[distance=..20] ~ ~ ~ 0.25 0.65
execute if entity @s[tag=nsp_mob.sound.jazz] run playsound minecraft:block.note_block.bass neutral @a[distance=..24] ~ ~ ~ 0.25 0.8

