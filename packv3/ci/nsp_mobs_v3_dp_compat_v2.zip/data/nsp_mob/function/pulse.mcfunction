execute store result score @s nspm_hp run data get entity @s Health 100
execute if score @s nspm_hp < @s nspm_oldhp run function nsp_mob:hurt
scoreboard players operation @s nspm_oldhp = @s nspm_hp
execute if score @s nspm_hurt matches 1 on passengers if entity @s[tag=nsp_mob.visual] run function nsp_mob:restore_brightness
execute if score @s nspm_hurt matches 1.. run scoreboard players remove @s nspm_hurt 1
scoreboard players add @s nspm_idle 1
execute if score @s nspm_idle matches 16.. run scoreboard players set @s nspm_idle 0
function nsp_mob:idle
execute if entity @s[tag=nsp_mob.pattern.idle] run scoreboard players set @s nspm_action 0
execute if entity @s[tag=nsp_mob.pattern.idle] run scoreboard players add @s nspm_perf 2
execute if entity @s[tag=nsp_mob.pattern.idle] if score @s nspm_perf matches 80.. run function nsp_mob:perform
execute if entity @s[tag=nsp_mob.pattern.idle] if score @s nspm_perf matches 80.. run scoreboard players set @s nspm_perf 0
execute if score @s nspm_cd matches 1.. run scoreboard players remove @s nspm_cd 2
execute unless entity @s[tag=nsp_mob.pattern.idle] if score @s nspm_cd matches ..0 if score @s nspm_action matches 0 run function nsp_mob:begin_attack
execute unless entity @s[tag=nsp_mob.pattern.idle] if score @s nspm_action matches 1.. run function nsp_mob:attack_tick
execute if entity @s[tag=nsp_mob.despawn] run function nsp_mob:despawn_tick
execute if score @s nspm_idle matches 0 if entity @a[distance=..28] run function nsp_mob:ambient
execute if score @s nspm_action matches 1.. run tag @s add nsp_mob.state.attack
execute if score @s nspm_action matches 0 run tag @s remove nsp_mob.state.attack
execute if score @s nspm_hurt matches 1.. run tag @s add nsp_mob.state.hurt
execute if score @s nspm_hurt matches 0 run tag @s remove nsp_mob.state.hurt
