execute if entity @s[tag=nsp_mob.pattern.idle] run scoreboard players set @s nspm_action 0
execute if entity @s[tag=nsp_mob.pattern.idle] run return 0
execute if entity @s[type=minecraft:vex,tag=nsp_mob.pattern.charge] run return fail
function nsp_mob:select_target
execute unless data storage nsp_mob:context target run scoreboard players set @s nspm_cd 20
execute unless data storage nsp_mob:context target run return 0
execute if entity @s[tag=nsp_mob.pattern.charge] run scoreboard players set @s nspm_action 10
execute if entity @s[tag=nsp_mob.pattern.burst] run scoreboard players set @s nspm_action 27
execute if entity @s[tag=nsp_mob.pattern.slam] run scoreboard players set @s nspm_action 8
execute if score @s nspm_action matches 1.. run scoreboard players set @s nspm_cd 100
execute if score @s nspm_action matches 1.. run function nsp_mob:sound/attack
execute if entity @s[tag=nsp_mob.pattern.slam] if score @s nspm_action matches 8 run function nsp_mob:sound/special
execute if entity @s[tag=nsp_mob.pattern.burst] if score @s nspm_action matches 27 run function nsp_mob:sound/special
