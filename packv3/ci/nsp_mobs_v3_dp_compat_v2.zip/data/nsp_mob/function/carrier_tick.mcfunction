execute if entity @s[nbt={Health:0.0f}] unless entity @s[tag=nsp_mob.death_played] run function nsp_mob:sound/death
execute if entity @s[nbt={Health:0.0f}] run tag @s add nsp_mob.death_played
scoreboard players add @s nspm_phase 1
execute if score @s nspm_phase matches 2.. run scoreboard players set @s nspm_phase 0
execute if score @s nspm_phase matches 0 run function nsp_mob:pulse
