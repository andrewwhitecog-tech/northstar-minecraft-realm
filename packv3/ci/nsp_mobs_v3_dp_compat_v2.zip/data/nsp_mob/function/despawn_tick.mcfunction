execute if entity @a[distance=..64] run scoreboard players set @s nspm_away 0
execute unless entity @a[distance=..64] run scoreboard players add @s nspm_away 2
execute if score @s nspm_away matches 6000.. run data merge entity @s {DeathLootTable:"nsp_mob:entities/empty"}
execute if score @s nspm_away matches 6000.. run kill @s
