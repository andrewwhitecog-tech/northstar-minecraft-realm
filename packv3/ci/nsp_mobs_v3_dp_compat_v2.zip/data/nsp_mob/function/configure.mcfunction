# Run as the newly summoned living carrier. Re-merge health after max_health, as in the real Harbinger seed.
$attribute @s minecraft:generic.max_health base set $(hp)
$attribute @s minecraft:generic.attack_damage base set $(damage)
$attribute @s minecraft:generic.scale base set $(scale)
$data merge entity @s {Health:$(hp)f}
execute if entity @s[type=minecraft:vex] store result entity @s BoundX int 1 run data get entity @s Pos[0]
execute if entity @s[type=minecraft:vex] store result entity @s BoundY int 1 run data get entity @s Pos[1]
execute if entity @s[type=minecraft:vex] store result entity @s BoundZ int 1 run data get entity @s Pos[2]
function nsp_mob:attach
tag @s remove nsp_mob.new
