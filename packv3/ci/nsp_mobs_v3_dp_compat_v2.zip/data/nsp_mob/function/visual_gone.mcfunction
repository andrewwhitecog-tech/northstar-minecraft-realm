scoreboard players add #generation nspm_stat 1
particle minecraft:reverse_portal ~ ~0.5 ~ 0.6 0.6 0.6 0.08 20 normal
execute if entity @a[distance=..28] run playsound minecraft:entity.evoker.prepare_summon hostile @a[distance=..28] ~ ~ ~ 0.5 0.6
kill @s
