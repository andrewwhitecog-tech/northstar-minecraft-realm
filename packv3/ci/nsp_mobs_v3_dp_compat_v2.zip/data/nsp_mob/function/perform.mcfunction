# Performer pulse every 80 loaded ticks. Vanilla note-block fallback, not a claimed custom sax recording.
particle minecraft:note ~ ~2.4 ~ 0.4 0.2 0.4 0 4 normal @a[distance=..24]
execute if entity @s[tag=nsp_mob.sound.jazz] run playsound minecraft:block.note_block.harp neutral @a[distance=..24] ~ ~ ~ 0.35 0.8
