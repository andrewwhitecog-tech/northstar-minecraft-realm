data remove storage nsp_mob:context target
data modify storage nsp_mob:context owner set from entity @s UUID
execute if entity @p[gamemode=survival,distance=..16] run data modify storage nsp_mob:context target set from entity @p[gamemode=survival,distance=..16] UUID
# Explicit private-test switch only; absent by default. Tests use real living target entities, never fake player passes.
execute if data storage nsp_mob:settings {training:1b} if entity @e[tag=nsp_mob.test_target,distance=..16,limit=1] run data modify storage nsp_mob:context target set from entity @e[tag=nsp_mob.test_target,distance=..16,limit=1,sort=nearest] UUID
