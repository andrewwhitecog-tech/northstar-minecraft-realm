# Timing is populated ONLY by the real owned server profiler, never derived from command count.
execute store result score #population nspm_stat run execute if entity @e[tag=nsp_mob.carrier]
execute unless data storage nsp_mob:profile {measured:1b} run tellraw @s [{"text":"nsp_mob: timing not measured. Run the owned server profiler; command count is not milliseconds."}]
execute unless data storage nsp_mob:profile {measured:1b} run return 0
execute unless data storage nsp_mob:profile generation run return 0
execute unless data storage nsp_mob:profile game_time run return 0
execute unless data storage nsp_mob:profile population run return 0
execute unless data storage nsp_mob:profile ms_per_mob run return 0
execute store result score #measured_count nspm_stat run data get storage nsp_mob:profile population
execute store result score #sample_generation nspm_stat run data get storage nsp_mob:profile generation
execute unless score #generation nspm_stat = #sample_generation nspm_stat run return 0
execute store result score #sample_time nspm_stat run data get storage nsp_mob:profile game_time
execute store result score #current_time nspm_stat run time query gametime
scoreboard players operation #current_time nspm_stat -= #sample_time nspm_stat
execute unless score #population nspm_stat = #measured_count nspm_stat run tellraw @s [{"text":"nsp_mob timing stale: population changed; re-measure."}]
execute unless score #population nspm_stat = #measured_count nspm_stat run return 0
execute unless score #current_time nspm_stat matches 0..200 run tellraw @s [{"text":"nsp_mob timing expired; re-measure."}]
execute unless score #current_time nspm_stat matches 0..200 run return 0
data get storage nsp_mob:profile ms_per_mob
data get storage nsp_mob:profile population
execute if entity @s[type=minecraft:player] run tellraw @s [{"text":"nsp_mob measured ms per mob: "},{"nbt":"ms_per_mob","storage":"nsp_mob:profile"},{"text":"; population: "},{"score":{"name":"#population","objective":"nspm_stat"}},{"text":". Scope: "},{"nbt":"scope","storage":"nsp_mob:profile"}]
return 1
