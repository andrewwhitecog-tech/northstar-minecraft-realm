execute as @e[tag=nsp_mob.carrier] at @s run function nsp_mob:carrier_tick
execute as @e[type=minecraft:item_display,tag=nsp_mob.visual] at @s run function nsp_mob:visual_tick
execute as @e[type=minecraft:shulker_bullet,tag=nsp_mob.projectile] run function nsp_mob:projectile_tick
