# Existing model summons can call this as their exact carrier with their display already riding it.
execute if entity @s[type=minecraft:vex,tag=nsp_mob.pattern.charge] run return fail
tag @s add nsp_mob.carrier
scoreboard players set @s nspm_phase 0
scoreboard players set @s nspm_cd 20
scoreboard players set @s nspm_action 0
scoreboard players set @s nspm_hurt 0
scoreboard players set @s nspm_idle 0
scoreboard players set @s nspm_away 0
execute store result score @s nspm_oldhp run data get entity @s Health 100
execute on passengers if entity @s[type=minecraft:item_display] run tag @s add nsp_mob.visual
scoreboard players add #generation nspm_stat 1
# A nonhostile performer is stationary; its visual still interpolates. No native combat AI or library attack.
scoreboard players set @s nspm_perf 0
execute if entity @s[tag=nsp_mob.pattern.idle] run data merge entity @s {NoAI:1b}
execute if entity @s[tag=nsp_mob.pattern.idle] run tag @s add nsp_mob.sound.jazz
execute if entity @s[tag=nsp_mob.crowned_giraffe_strider_v2] run data merge entity @s {NoAI:0b}
execute if entity @s[tag=nsp_mob.crowned_giraffe_strider_v2] run tag @s remove nsp_mob.sound.jazz
execute if entity @s[tag=nsp_mob.crowned_giraffe_strider_v2_glow] run data merge entity @s {NoAI:0b}
execute if entity @s[tag=nsp_mob.crowned_giraffe_strider_v2_glow] run tag @s remove nsp_mob.sound.jazz
execute if entity @s[tag=nsp_mob.crowned_giraffe_strider_v2_iridescent] run data merge entity @s {NoAI:0b}
execute if entity @s[tag=nsp_mob.crowned_giraffe_strider_v2_iridescent] run tag @s remove nsp_mob.sound.jazz
execute if entity @s[tag=nsp_mob.goliath_tusk_elephant] run data merge entity @s {NoAI:0b}
execute if entity @s[tag=nsp_mob.goliath_tusk_elephant] run tag @s remove nsp_mob.sound.jazz
execute if entity @s[tag=nsp_mob.goliath_tusk_elephant_glow] run data merge entity @s {NoAI:0b}
execute if entity @s[tag=nsp_mob.goliath_tusk_elephant_glow] run tag @s remove nsp_mob.sound.jazz
execute if entity @s[tag=nsp_mob.goliath_tusk_elephant_iridescent] run data merge entity @s {NoAI:0b}
execute if entity @s[tag=nsp_mob.goliath_tusk_elephant_iridescent] run tag @s remove nsp_mob.sound.jazz
execute if entity @s[tag=nsp_mob.paradise_sunburst_toucan] run data merge entity @s {NoAI:0b}
execute if entity @s[tag=nsp_mob.paradise_sunburst_toucan] run tag @s remove nsp_mob.sound.jazz
execute if entity @s[tag=nsp_mob.paradise_sunburst_toucan_glow] run data merge entity @s {NoAI:0b}
execute if entity @s[tag=nsp_mob.paradise_sunburst_toucan_glow] run tag @s remove nsp_mob.sound.jazz
execute if entity @s[tag=nsp_mob.paradise_sunburst_toucan_iridescent] run data merge entity @s {NoAI:0b}
execute if entity @s[tag=nsp_mob.paradise_sunburst_toucan_iridescent] run tag @s remove nsp_mob.sound.jazz
